%% ENG 6 Project 1
% Jaserah Hannan
% Section A06
% SID: 914069289

table = fopen('rank_table.txt', 'w');
inputCell = inputdlg('Please enter one of the given options on how you want to sort your file: 1.Solar  2.Wind  3.Precipation');
N = str2num(inputCell{:});
for (i = 1:length(city))
    avg_solar(i) = ((sum(solar(i,:)))/(12));
    avg_wind(i) = ((sum(wind(i,:)))/(12));
    avg_precip(i) = ((sum(precip(i,:)))/(12));
end
sort_solar = sort(avg_solar, 'descend');
i = 1;
while i <= length(city)
    if (length(find(avg_solar(i) == sort_solar)) == 1)
        ranked_solar(i) = find(avg_solar(i) == sort_solar);
        i = i + 1;
    else (length(find(avg_solar(i) == sort_solar)) == 2)
        same_rankings = find(avg_solar(i) == sort_solar);
        ranked_solar(i) = same_rankings(1);
        ranked_solar(i+1) = same_rankings(2);
        i = i + 2;
    end
end
sort_wind = sort(avg_wind, 'descend');
i = 1;
while i <= length(city)
    if (length(find(avg_wind(i) == sort_wind)) == 1)
        ranked_wind(i) = find(avg_wind(i) == sort_wind);
        i = i + 1;
    elseif (length(find(avg_wind(i) == sort_wind)) == 2)
        same_rankings = find(avg_wind(i) == sort_wind);
        ranked_wind(i) = same_rankings(1);
        ranked_wind(i+1) = same_rankings(2);
        i = i + 2;
    elseif (length(find(avg_wind(i) == sort_wind)) == 3)
        same_rankings = find(avg_wind(i) == sort_wind);
        ranked_wind(i) = same_rankings(1);
        ranked_wind(i+1) = same_rankings(2);
        ranked_wind(i+2) = same_rankings(3);
        i = i + 3;
    elseif (length(find(avg_wind(i) == sort_wind)) == 3)
        same_rankings = find(avg_wind(i) == sort_wind);
        ranked_wind(i) = same_rankings(1);
        ranked_wind(i+1) = same_rankings(2);
        ranked_wind(i+2) = same_rankings(3);
        ranked_wind(1+3) = same_rankings(3);
        i = i + 4;
    end
end
sort_precip = sort(avg_precip, 'descend');
i = 1;
while i <= length(city)
    if (length(find(avg_precip(i) == sort_precip)) == 1)
        ranked_precip(i) = find(avg_precip(i) == sort_precip);
        i = i + 1;
    else if (length(find(avg_precip(i) == sort_precip)) == 2)
        same_rankings = find(avg_precip(i) == sort_precip);
        ranked_precip(i) = same_rankings(1);
        ranked_precip(i+1) = same_rankings(2);
        i = i + 2;
    else (length(find(avg_precip(i) == sort_precip)) == 3)
        same_rankings = find(avg_precip(i) == sort_precip);
        ranked_precip(i) = same_rankings(1);
        ranked_precip(i+1) = same_rankings(2);
        ranked_precip(i+2) = same_rankings(3);
        i = i + 3;
        end
    end
end
if (N == 1)
    fprintf(table, '   City       Solar Rank  Wind Rank   Precipitation Rank\n');
    for i = 1:length(city)
        location(i) = find(ranked_solar == i);
        wind_location(i) = ranked_wind(location(i));
        precip_location(i) = ranked_precip(location(i));
        fprintf(table, '%s     %.0f          %.0f             %0.f\n', city(i,:), i, wind_location(i), precip_location(i));
    end
end

if (N == 2)
    fprintf(table, '   City       Solar Rank  Wind Rank   Precipitation Rank\n');
    for i = 1:length(city)
        location(i) = find(ranked_wind == i);
        solar_location(i) = ranked_solar(location(i));
        precip_location(i) = ranked_precip(location(i));
        fprintf(table, '%s     %.0f          %.0f             %0.f\n', city(i,:), solar_location(i), i, precip_location(i));
    end 
end

if (N == 3)
    fprintf(table, '   City       Solar Rank  Wind Rank   Precipitation Rank\n');
    for i = 1:length(city)
        location(i) = find(ranked_precip == i);
        solar_location(i) = ranked_solar(location(i));
        wind_location(i) = ranked_wind(location(i));
        fprintf(table, '%s     %.0f          %.0f             %0.f\n', city(i,:), solar_location(i), i, precip_location(i));
    end 
end

fclose(table);



