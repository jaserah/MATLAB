%% ENG 6 Project 1
% Jaserah Hannan
% Section A06
% SID: 914069289

%% Task 2

letter_B = find(city =='B');
fprintf('Task 2: In total, %.0f cities in the database have names starting with the letter B.\n', length(letter_B));

%% Task 3
i = 1;
j = 2;
num_states = 0;
while (i <= length(city))
    while (j <= length(city))
        if state(i) ~= state(j)
            num_states = num_states + 1;
        end
        j = j + 1;
    end
    i = i + 1;
end
fprintf('Task 3: In total, %.0f states exist in the database.\n', num_states);

%% Task 4

no_space_city = isspace(city);

for i = 1:length(city)
    length_cities(i) = length(find(no_space_city(i, :) == 0));
end

num_cities_longer = length(find(length_cities > 6));

fprintf('Task 4: %.0f cities in the database have names longer than 6 characters.\n', num_cities_longer);


%% Task 5

for i = 1:length(city)
    sum_wind(i) = sum(wind(i,:));
end

most_wind = find(sum_wind == max(sum_wind));
max_location = city(most_wind, :);
least_wind = find(sum_wind == min(sum_wind));
min_location = city(least_wind, :);

fprintf('Task 5: %s experiences the most wind while %s experiences the least wind.\n', strtrim(max_location), strtrim(min_location));

%% Task 6

for i = 1:length(city)
    avg_wind(i) = ((sum(wind(i,:)))/(12));
end
large_avg_wind = length(find(avg_wind > 9));
avg_wind_percent = (large_avg_wind/length(city)) * 100;

fprintf('Task 6: %.2f percent of cities have monthly wind speed greater than 9 mph.\n', avg_wind_percent);

%% Task 7

for i = 1:length(city)
    winter_spring_wind(i) = sum(wind(i, 1:5)) + wind(i, 12);
end
max_winter_spring = find(winter_spring_wind == max(winter_spring_wind));
location_winter_spring = city(max_winter_spring, :);

fprintf('Task 7: %s has the highest wind speed during the winter and spring seasons.\n', strtrim(location_winter_spring));

%% Task 8

for i = 1:length(city)
    least_solar_per_month(i) = min(solar(i, :));
    least_solar = min(least_solar_per_month);
    least_solar_location = find(least_solar_per_month == least_solar);
    least_solar_month = find(solar(least_solar_location, :) == least_solar);
end

switch least_solar_month
    case 1
        month = 'January';
    case 2
        month = 'February';
    case 3
        month = 'March';
    case 4
        month = 'April';
    case 5
        month = 'May';
    case 6
        month = 'June';
    case 7 
        month = 'July';
    case 8 
        month = 'August';
    case 9
        month = 'September';
    case 10
        month = 'October';
    case 11
        month = 'November';
    case 12 
        month = 'December';
end

fprintf('Task 8: %s has the least monthly solar insolation in %s.\n', strtrim(city(least_solar_location, :)), month); 

%% Task 9

for i = 1:length(city)
    avg_solar(i) = ((sum(solar(i,:)))/(12));
end
large_avg_solar = length(find(avg_solar > 3.5));

fprintf('Task 9: %.0f cities have solar insolation greater than 3.5 kW per square meter.\n', large_avg_solar);

%% Task 10

for i = 1:length(city)
    solar_june(i) = solar(i, 6);
    solar_jan(i) = solar(i, 1);
end

large_solar_june = find(solar_june == max(solar_june));
location_june = city(large_solar_june, :);
large_solar_jan = find(solar_jan == max(solar_jan));
location_jan = city(large_solar_jan, :);

fprintf('Task 10: %s has the largest solar insolation in June, while %s has the largest in January.\n', strtrim(location_june), strtrim(location_jan));

%% Task 11

for i = 1:length(city)
    avg_solar(i) = ((sum(solar(i,:)))/(12));
end
have_panels = find(avg_solar > 3.5);
for i = have_panels
    avg_wind_panels(i) = ((sum(wind(i,:)))/(12));
end

risk_damage = find(avg_wind_panels > 5);

wind_panels_sorted = sort(avg_wind_panels ,'descend');
first_most_damage = find(avg_wind == wind_panels_sorted(1));
second_most_damage = find(avg_wind == wind_panels_sorted(2));
third_most_damage = find(avg_wind == wind_panels_sorted(3));
location_first_damage = strtrim(city(first_most_damage,:));
location_second_damage = strtrim(city(second_most_damage,:));
location_third_damage = strtrim(city(third_most_damage(1),:));

fprintf('Task 11: In order of likeliness to damage solar panels: %s, %s, %s.\n', location_first_damage, location_second_damage, location_third_damage);

%% Task 12

for i = 1:length(city)
    precip_march(i) = precip(i, 3);
    precip_dec(i) = precip(i, 12);
end

most_rain_march = sort(precip_march, 'descend');
most_rain_march1 = strtrim(city(find(precip_march == most_rain_march(1)),:));
most_rain_march2 = strtrim(city(find(precip_march == most_rain_march(2)),:));
most_rain_march3 = strtrim(city(find(precip_march == most_rain_march(3)),:));
most_rain_dec = sort(precip_dec, 'descend');
most_rain_dec1 = strtrim(city(find(precip_dec == most_rain_dec(1)),:));
most_rain_dec2 = strtrim(city(find(precip_dec == most_rain_dec(2)),:));
most_rain_dec3 = strtrim(city(find(precip_dec == most_rain_dec(3)),:));

fprintf('Task 12: %s, %s and %s experience the most rain in March while %s, %s, and %s experience the most rain in December.\n', most_rain_march1, most_rain_march2, most_rain_march3, most_rain_dec1, most_rain_dec2, most_rain_dec3);

%% Task 13

for i = 1:length(city)
    avg_rain(i) = ((sum(precip(i,:)))/(12));
end

reduce5 = find(avg_wind < 3);
reduce10 = find((avg_wind > 3) & (avg_wind < 5));
reduce30 = find(avg_wind  > 5);
avg_rain(reduce5) = avg_rain(reduce5) - (avg_rain(reduce5) * 0.05);
avg_rain(reduce10) = avg_rain(reduce10) - (avg_rain(reduce10) * 0.10);
avg_rain(reduce30) = avg_rain(reduce30) - (avg_rain(reduce30) * 0.30);

most_rain_no_wind = strtrim(city(find(avg_rain == max(avg_rain)),:));
fprintf('Task 13: Accounting for loss due to strong winds. %s collects the most rainwater in a year.\n', most_rain_no_wind);

%% Task 14

risk_rain_damage =  find((avg_wind_panels > 5) & (avg_rain > 2));
rain_damage_rainfall = avg_rain(risk_rain_damage);
highest_rainfall = sort(rain_damage_rainfall, 'descend');

first_most_rain = find(avg_rain == highest_rainfall(1));
location_first_rain = strtrim(city(first_most_rain,:));
second_most_rain = find(avg_rain == highest_rainfall(2));
location_second_rain = strtrim(city(second_most_rain,:));
third_most_rain = find(avg_rain == highest_rainfall(3));
location_third_rain = strtrim(city(third_most_rain,:));

fprintf('Task 14: In order to likeliness to have solar panels damaged due to rain and wind: %s, %s, and %s.\n', location_first_rain, location_second_rain, location_third_rain);


%% Task 15

install_wind_turbines = length(find(avg_wind > avg_solar));
fprintf('Task 15: %.0f cities should install wind turbines.\n', install_wind_turbines);

%% Task 16

install_wind_and_solar = length(find((avg_wind>avg_solar) & (avg_solar>3.9)));
fprintf('Task 16: %.0f cities should install both solar panels and wind turbines.\n', install_wind_and_solar);

%% Task 17

yearly_solar = avg_solar * 12;
yearly_wind = avg_wind * 12 * 2 / 5;
both_unsuitable = find((yearly_solar < 42) & (yearly_wind < 42));
fprintf('Task 17: %.0f cities are UNSUITABLE to use both wind and solar power. %s, %s.\n', length(both_unsuitable), strtrim(city(both_unsuitable(1),:)), strtrim(city(both_unsuitable(2),:)));

%% Task 18

suitable_at_least1 = length(find(((yearly_solar > 60) | (yearly_wind > 75)) | ((yearly_solar >60) & (yearly_wind > 75))));
fprintf('Task 18: %.0f cities are SUITABLE for at least one type of renewable energy.\n', suitable_at_least1);

%% Task 19

suitable_only1 = length(find((yearly_solar > 60) | (yearly_wind > 75)));
fprintf('Task 19: %.0f cities are SUITABLLE for ONLY ONE type of renewable energy.\n', suitable_only1);

%% Task 20

adequate_for_both = length(find(((yearly_solar < 60) & (yearly_solar > 42)) & ((yearly_wind < 75) & (yearly_wind > 42))));
fprintf('Task 20: %.0f cities are ADEQUATE for both solar and wind power.\n', adequate_for_both);

%% Task 21

figure(1)
% city(49,:) = washington
set(plot(solar(49,:),'-.r'), 'LineWidth', 2.5);
hold on
set(plot(wind(49,:), 'r'), 'LineWidth', 2.5);
hold on
set(plot(precip(49,:), ':r'), 'LineWidth', 2.5);
hold on
% city(51,:) = seattle
set(plot(solar(51,:), '-.b'), 'LineWidth', 2.5);
hold on
set(plot(wind(51,:), 'b'), 'LineWidth', 2.5);
hold on
set(plot(precip(51,:), ':b'), 'LineWidth', 2.5);
hold on
% city(4,:) = phoenix
set(plot(solar(4,:), '-.m'), 'LineWidth', 2.5);
hold on 
set(plot(wind(4,:), 'm'), 'LineWidth', 2.5);
hold on
set(plot(precip(4,:), ':m'), 'LineWidth', 2.5);
ylabel('Energy');
xlabel('Month');
legend('Washington: solar', 'Washington: wind', 'Washington: precipitation', 'Seattle: solar', 'Seattle: wind', 'Seattle: precipitation', 'Phoenix: solar', 'Phoenix: wind', 'Phoenix: precipitation');
title('Solar, Wind and Precipitation Data for 12 Months');
