%% ENG 6 Project 1
% Jaserah Hannan
% Section A06
% SID: 914069289

%% BONUS: Task 23

correlation = sum_square(solar, precip))/(sqrt((sum_square(solar, solar))*(sum_square(precip, precip))));

function out = sum_square(x,y)
for i = 1:length(city)
    out = (sum(x(i,:)) + sum(y(i,:)))/length(x(i,:));
end
end
